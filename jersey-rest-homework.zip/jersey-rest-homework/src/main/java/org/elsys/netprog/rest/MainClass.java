package org.elsys.netprog.rest;

import java.security.MessageDigest;

public class MainClass {
	
	private int lenght;
	private String hash;
	MainClass() {
		int lenght = this.lenght;
		String hash = this.hash;
	}
	
}
