package org.elsys.netprog.rest;

import java.net.URI;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/")
public class MainController {
	
	@POST
	@Path("/{input_hash}")
	@Produces(value={MediaType.APPLICATION_JSON})
	public Response input(@PathParam("input_hash") Integer input_hash) {
		Hash hash;
		
		return Response.created(new URI("/")).build();
	}
	
	@GET
	@Path("/{lenght}/{hash}")
	@Produces(value={MediaType.APPLICATION_JSON})
	public Response gethash(@PathParam("lenght") Integer l, @PathParam("hash") String h) {
		
		
		return Response.status(200).build();
	}
	
	
}
