package org.elsys.netprog.rest;

import java.security.MessageDigest;
import java.util.Base64;

public class Hash {
	
	private int lenght;
	private Base64 input;
	private String hash;
	Hash() {
		Base64 input = this.input;
		int lenght = get;
		String hash;
	}
	
	public String generateHash(int input, int lenght){
		return 
	}
}
